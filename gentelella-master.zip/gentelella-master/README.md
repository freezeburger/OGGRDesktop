# gentelella

Gentellela Admin is a free to use Bootstrap admin template. 
This template uses the default Bootstrap 3.x.x styles along with a variety of powerful jQuery plugins and tools
 to create a powerful framework for creating admin panels or back-end dashboards.
